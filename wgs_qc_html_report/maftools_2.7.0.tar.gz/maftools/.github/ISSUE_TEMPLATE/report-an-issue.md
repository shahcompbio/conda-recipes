---
name: Report an issue
about: Report an issue to help improve the package
title: ''
labels: ''
assignees: ''

---

**Describe the issue**
A clear and concise description of what the issue is.

**Command**
Please post your commands and the output (errors or any unexpected output)

```r
```


**Session info**
Run `sessionInfo()` and post the output below

```r
```
